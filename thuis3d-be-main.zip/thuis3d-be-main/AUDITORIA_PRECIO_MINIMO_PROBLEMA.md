# 🔍 Auditoría: Problema con Cálculo de Precio Mínimo

## 📋 RESUMEN DEL PROBLEMA

**Síntoma reportado:**
- Usuario configura: margen de ganancia = 0, insumos = 0, precio mínimo = 0.1€
- Resultado: cotización sale exactamente 0.1€
- Esperado: debería mostrar el valor real calculado (material + electricidad + desgaste + margen de error)

---

## 🔎 ANÁLISIS DEL CÓDIGO ACTUAL

### Ubicación: `src/lib/stlAnalyzer.ts` líneas 605-624

```javascript
// 5. SUBTOTAL SIN INSUMOS (costo base)
const baseCost = materialCost + electricityCost + machineCost;

// 6. MARGEN DE ERROR (29%)
const errorMarginCost = baseCost * (errorMarginPercentage / 100);

// 7. SUBTOTAL CON MARGEN DE ERROR (costo seguro)
const safeCost = baseCost + errorMarginCost;

// 8. APLICAR MULTIPLICADOR DE GANANCIA
const retailPrice = safeCost * profitMultiplier;  // ⚠️ PROBLEMA AQUÍ

// 9. PROTECCIÓN: Precio mínimo
const totalWithoutSupplies = Math.max(retailPrice, configuredMinimumPrice);

// 10. TOTAL FINAL CON INSUMOS
const totalPerUnit = totalWithoutSupplies + suppliesCost;

// 11. APLICAR CANTIDAD
const estimatedTotal = totalPerUnit * quantity;
```

---

## 🐛 CAUSA RAÍZ DEL PROBLEMA

### **Error conceptual en el multiplicador de ganancia**

El `profitMultiplier` es un **MULTIPLICADOR**, no un porcentaje:

| Valor | Significado | Ganancia |
|-------|------------|----------|
| 5.0 | Precio final = 5x el costo | 400% ganancia |
| 2.0 | Precio final = 2x el costo | 100% ganancia |
| 1.5 | Precio final = 1.5x el costo | 50% ganancia |
| 1.0 | Precio final = 1x el costo | 0% ganancia (precio de costo) |
| **0.0** | Precio final = 0x el costo | **⚠️ PRECIO = 0€** |

### **Flujo del problema:**

1. Usuario configura `profitMultiplier = 0`
2. Cálculo real:
   - Material: 2€
   - Electricidad: 0.50€
   - Desgaste: 0.30€
   - **baseCost** = 2.80€
   - Margen error (29%): 0.81€
   - **safeCost** = 3.61€
3. Aplicar multiplicador:
   - **retailPrice** = 3.61€ × **0** = **0€**
4. Aplicar mínimo:
   - **totalWithoutSupplies** = Math.max(**0€**, 0.1€) = **0.1€**
5. Resultado final: **0.1€** ❌

**Por eso siempre sale 0.1€, porque el multiplicador de 0 anula el cálculo real.**

---

## ✅ SOLUCIÓN CORRECTA

### Cambio en línea 615:

**ANTES (incorrecto):**
```javascript
const retailPrice = safeCost * profitMultiplier;
```

**DESPUÉS (correcto):**
```javascript
// Si profitMultiplier es 0, usar directamente safeCost (precio de costo)
// Si profitMultiplier >= 1, aplicar el multiplicador normalmente
const retailPrice = profitMultiplier > 0 ? safeCost * profitMultiplier : safeCost;
```

### Lógica corregida:

| `profitMultiplier` | `retailPrice` | Comportamiento |
|-------------------|---------------|----------------|
| 0 | safeCost (sin multiplicar) | Precio de costo puro |
| 1.0 | safeCost × 1.0 = safeCost | Sin ganancia (0%) |
| 1.5 | safeCost × 1.5 | 50% de ganancia |
| 5.0 | safeCost × 5.0 | 400% de ganancia |

---

## 🎯 COMPORTAMIENTO ESPERADO DESPUÉS DEL FIX

### Escenario de prueba 1:
**Configuración:**
- `profitMultiplier = 0` (o se elimina)
- `suppliesCost = 0`
- `minimum_price = 0.1€`

**Resultado esperado:**
- Material: 2€
- Electricidad: 0.50€
- Desgaste: 0.30€
- baseCost: 2.80€
- errorMargin: 0.81€
- safeCost: **3.61€**
- retailPrice: **3.61€** (no se multiplica por 0)
- totalWithoutSupplies: Math.max(3.61€, 0.1€) = **3.61€**
- **Precio final: 3.61€** ✅

### Escenario de prueba 2:
**Configuración:**
- `profitMultiplier = 0`
- `suppliesCost = 0.50€`
- `minimum_price = 7€`
- Cálculo real: 2€

**Resultado esperado:**
- safeCost: 2.58€
- retailPrice: 2.58€
- totalWithoutSupplies: Math.max(2.58€, 7€) = **7€** (aplica mínimo)
- totalPerUnit: 7€ + 0.50€ = **7.50€** ✅

### Escenario de prueba 3:
**Configuración:**
- `profitMultiplier = 1.5` (50% ganancia)
- `suppliesCost = 1€`
- `minimum_price = 5€`
- Cálculo real: 3€

**Resultado esperado:**
- safeCost: 3.87€
- retailPrice: 3.87€ × 1.5 = **5.81€**
- totalWithoutSupplies: Math.max(5.81€, 5€) = **5.81€**
- totalPerUnit: 5.81€ + 1€ = **6.81€** ✅

---

## 📝 VALIDACIÓN ADICIONAL

### También revisar el logging (línea 626-636):

```javascript
console.log('💰 Cálculo de precio:', {
  costoBase: baseCost.toFixed(2) + '€',
  margenError: errorMarginCost.toFixed(2) + '€ (+' + errorMarginPercentage + '%)',
  costoSeguro: safeCost.toFixed(2) + '€',
  multiplicadorGanancia: profitMultiplier, // ⬅️ AÑADIR ESTE LOG
  precioRetail: retailPrice.toFixed(2) + '€',
  precioMínimoConfig: configuredMinimumPrice.toFixed(2) + '€',
  precioFinalUnidad: totalPerUnit.toFixed(2) + '€',
  cantidad: quantity,
  precioFinalTotal: estimatedTotal.toFixed(2) + '€',
  aplicado: totalWithoutSupplies === configuredMinimumPrice ? 'PRECIO MÍNIMO' : 'PRECIO RETAIL'
});
```

---

## 🔧 RECOMENDACIÓN PARA EL ADMINISTRADOR

En la interfaz de configuración (`PrintingCalculatorSettings.tsx`), añadir una nota aclaratoria:

```
Multiplicador de Ganancia:
- 1.0 = Sin ganancia (precio de costo)
- 1.5 = 50% de ganancia sobre el costo
- 2.0 = 100% de ganancia (duplica el costo)
- 5.0 = 400% de ganancia

⚠️ No usar 0, ya que anula el cálculo. Usa 1.0 para precio de costo.
```

---

## 📊 IMPACTO DEL CAMBIO

- ✅ Respeta el cálculo real de costos cuando `profitMultiplier = 0`
- ✅ Mantiene compatibilidad con valores >= 1
- ✅ El precio mínimo solo se aplica cuando el cálculo real es menor
- ✅ Los logs muestran correctamente qué se aplicó

---

## 🧪 PRUEBAS RECOMENDADAS

1. **Prueba con profitMultiplier = 0:**
   - Subir un STL de ~10g
   - Verificar que el precio sea > 0.1€ (costo real)

2. **Prueba con profitMultiplier = 1.0:**
   - Mismo STL
   - Verificar que el precio sea igual al caso anterior

3. **Prueba con minimum_price alto:**
   - Configurar minimum_price = 10€
   - Subir un STL pequeño que costaría 2€
   - Verificar que el precio final sea 10€ (aplicó mínimo)

4. **Prueba con profitMultiplier = 2.0:**
   - Verificar que el precio sea aproximadamente el doble del costo base

---

## ✅ ESTADO

- [x] Problema identificado
- [ ] Solución implementada
- [ ] Pruebas realizadas
- [ ] Validado en producción
