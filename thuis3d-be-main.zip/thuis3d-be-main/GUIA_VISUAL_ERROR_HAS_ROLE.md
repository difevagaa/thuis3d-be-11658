# 🎨 Guía Visual - Error has_role

> **Guía ilustrada paso a paso**  
> Ideal para usuarios que prefieren diagramas y capturas de pantalla  
> **Tiempo**: 10-15 minutos

---

## 📊 Diagrama del Problema

```
┌─────────────────────────────────────────────────────────────┐
│                    FLUJO DEL PROBLEMA                        │
└─────────────────────────────────────────────────────────────┘

Usuario intenta crear política RLS
         ↓
    ┌────────────────────────────────────┐
    │  CREATE POLICY "Solo admins..."    │
    │  WITH CHECK (                      │
    │    public.has_role(               │  ← Usa la función has_role
    │      auth.uid(), 'admin'          │
    │    )                              │
    │  );                               │
    └────────────────────────────────────┘
         ↓
    🔍 Supabase busca la función has_role
         ↓
         ✗ ¡NO LA ENCUENTRA!
         ↓
    ┌────────────────────────────────────┐
    │  ❌ ERROR                          │
    │                                    │
    │  function public.has_role(uuid,    │
    │  text) does not exist              │
    └────────────────────────────────────┘
```

---

## 🏗️ Arquitectura del Sistema de Roles

```
┌──────────────────────────────────────────────────────────────────┐
│                    SISTEMA DE ROLES COMPLETO                      │
└──────────────────────────────────────────────────────────────────┘

┌─────────────────────┐
│   auth.users        │  ← Tabla de usuarios de Supabase
│  ─────────────────  │
│  id (UUID)          │
│  email              │
│  created_at         │
└──────────┬──────────┘
           │
           │ Relación 1:N (un usuario puede tener múltiples roles)
           │
           ↓
┌─────────────────────┐
│  public.user_roles  │  ← Tabla que almacena roles asignados
│  ─────────────────  │
│  id (UUID)          │
│  user_id (FK) ───────┘
│  role (TEXT)        │  ← 'admin', 'client', 'moderator'
│  created_at         │
└──────────┬──────────┘
           │
           │ Usada por
           │
           ↓
┌──────────────────────────────────────────┐
│  public.has_role(user_id, role)          │  ← Función helper
│  ──────────────────────────────────────  │
│  Verifica si un usuario tiene un rol     │
│  específico                              │
│                                          │
│  Retorna: BOOLEAN (true/false)           │
└──────────┬───────────────────────────────┘
           │
           │ Usada en
           │
           ↓
┌──────────────────────────────────────────┐
│  RLS POLICIES                            │  ← Políticas de seguridad
│  ──────────────────────────────────────  │
│  - Solo admins pueden INSERT            │
│  - Solo admins pueden UPDATE            │
│  - Solo admins pueden DELETE            │
│  - Todos pueden SELECT                  │
└──────────────────────────────────────────┘
```

---

## 🎯 Proceso de Solución Visual

```
┌──────────────────────────────────────────────────────────────────┐
│               PROCESO DE SOLUCIÓN (3 PASOS)                       │
└──────────────────────────────────────────────────────────────────┘

PASO 1: Crear la tabla user_roles
═══════════════════════════════════
┌─────────────────────────────────┐
│ CREATE TABLE user_roles (       │
│   id UUID,                       │
│   user_id UUID,                  │
│   role TEXT,                     │
│   created_at TIMESTAMPTZ         │
│ );                               │
└─────────────────────────────────┘
         ↓
    ✅ Tabla creada


PASO 2: Crear la función has_role
═══════════════════════════════════
┌─────────────────────────────────┐
│ CREATE FUNCTION has_role(       │
│   _user_id uuid,                 │
│   _role text                     │
│ ) RETURNS boolean                │
│ AS $$                            │
│   SELECT EXISTS (                │
│     SELECT 1 FROM user_roles    │
│     WHERE user_id = _user_id    │
│       AND role = _role          │
│   )                              │
│ $$;                              │
└─────────────────────────────────┘
         ↓
    ✅ Función creada


PASO 3: Asignar rol de admin
═══════════════════════════════════
┌─────────────────────────────────┐
│ INSERT INTO user_roles          │
│   (user_id, role)                │
│ VALUES                           │
│   (tu_user_id, 'admin');        │
└─────────────────────────────────┘
         ↓
    ✅ Admin asignado


RESULTADO FINAL
═══════════════════════════════════
┌─────────────────────────────────┐
│  ✅ Sistema funcionando          │
│  ✅ Políticas RLS operativas     │
│  ✅ has_role disponible          │
└─────────────────────────────────┘
```

---

## 🖥️ Capturas de Pantalla Simuladas

### 1. Pantalla de inicio de Supabase

```
╔════════════════════════════════════════════════════════╗
║  🟢 Supabase Dashboard                    usuario@... ▼║
╠════════════════════════════════════════════════════════╣
║                                                         ║
║  📊 Proyectos                                          ║
║  ┌─────────────────────────────────────────────────┐  ║
║  │  📦 thuis3d-production                          │  ║
║  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║  │  Status: 🟢 Active                              │  ║
║  │  Region: eu-west-1                              │  ║
║  │  Database: PostgreSQL 15                        │  ║
║  │                                                 │  ║
║  │  [Ver Dashboard] [Configuración]               │  ║
║  └─────────────────────────────────────────────────┘  ║
║                                                         ║
╚════════════════════════════════════════════════════════╝
```

### 2. SQL Editor

```
╔═══════════════════════════════════════════════════════════════╗
║  Supabase > thuis3d-production > 📝 SQL Editor               ║
╠═══════════════════════════════════════════════════════════════╣
║                                                                ║
║  New query  History  Favorites  Templates         ▶️ RUN      ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                                                                ║
║   1  -- Pega aquí el script de solución                       ║
║   2  CREATE TABLE IF NOT EXISTS public.user_roles (           ║
║   3    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),         ║
║   4    user_id UUID NOT NULL REFERENCES auth.users(id),       ║
║   5    role TEXT NOT NULL DEFAULT 'client',                   ║
║   6    created_at TIMESTAMPTZ DEFAULT NOW()                   ║
║   7  );                                                        ║
║   8                                                            ║
║   9  CREATE OR REPLACE FUNCTION public.has_role(              ║
║  10    _user_id uuid, _role text                              ║
║  11  ) RETURNS boolean AS $$                                  ║
║  12    SELECT EXISTS (                                         ║
║  13      SELECT 1 FROM public.user_roles                      ║
║  14      WHERE user_id = _user_id AND role = _role           ║
║  15    )                                                       ║
║  16  $$ LANGUAGE sql STABLE;                                  ║
║  17                                                            ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                                                                ║
║  📊 Results (después de ejecutar):                            ║
║  ┌──────────────────────────────────────────────────────┐    ║
║  │ NOTICE: ✅ Tabla user_roles creada                   │    ║
║  │ NOTICE: ✅ Función has_role creada                   │    ║
║  │ SUCCESS: Query completed in 245ms                     │    ║
║  └──────────────────────────────────────────────────────┘    ║
║                                                                ║
╚═══════════════════════════════════════════════════════════════╝
```

### 3. Verificación exitosa

```
╔═══════════════════════════════════════════════════════════════╗
║  📊 Resultados de Verificación                               ║
╠═══════════════════════════════════════════════════════════════╣
║                                                                ║
║  Componente              │  Estado                            ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║  1. Función has_role    │  ✅ OK                             ║
║  2. Tabla user_roles    │  ✅ OK                             ║
║  3. Usuarios admin      │  ✅ OK - 1 admin(s)                ║
║                                                                ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                                                                ║
║  Usuarios con Roles:                                          ║
║  ┌────────────────────────────────────────────────────────┐  ║
║  │ Rol    │ Email                  │ Fecha Asignación    │  ║
║  │────────│────────────────────────│─────────────────────│  ║
║  │ admin  │ admin@thuis3d.com      │ 2024-11-24 10:30   │  ║
║  │ client │ cliente1@example.com   │ 2024-11-24 11:15   │  ║
║  │ client │ cliente2@example.com   │ 2024-11-24 11:20   │  ║
║  └────────────────────────────────────────────────────────┘  ║
║                                                                ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## 🔄 Flujo de Trabajo Completo

```
┌────────────────────────────────────────────────────────────────┐
│              FLUJO DE TRABAJO PASO A PASO                       │
└────────────────────────────────────────────────────────────────┘

INICIO
  │
  ├─► 1. Identificar el error
  │   ┌──────────────────────────────────────────┐
  │   │ ❌ function public.has_role does not     │
  │   │    exist                                 │
  │   └──────────────────────────────────────────┘
  │
  ├─► 2. Abrir Supabase Dashboard
  │   ┌──────────────────────────────────────────┐
  │   │ 🌐 https://supabase.com/dashboard       │
  │   │ 🔐 Iniciar sesión                        │
  │   │ 📦 Seleccionar proyecto                  │
  │   └──────────────────────────────────────────┘
  │
  ├─► 3. Ir a SQL Editor
  │   ┌──────────────────────────────────────────┐
  │   │ 📝 Menu lateral → SQL Editor             │
  │   │ ➕ New Query                             │
  │   └──────────────────────────────────────────┘
  │
  ├─► 4. Ejecutar diagnóstico (opcional)
  │   ┌──────────────────────────────────────────┐
  │   │ 📄 Copiar scripts/diagnostico_has_role   │
  │   │ 📋 Pegar en SQL Editor                   │
  │   │ ▶️  Ejecutar (RUN)                       │
  │   │ 👀 Revisar resultados                    │
  │   └──────────────────────────────────────────┘
  │
  ├─► 5. Aplicar solución
  │   ┌──────────────────────────────────────────┐
  │   │ 📄 Copiar script de solución             │
  │   │ 📋 Pegar en SQL Editor                   │
  │   │ ▶️  Ejecutar (RUN)                       │
  │   │ ✅ Ver mensajes de confirmación          │
  │   └──────────────────────────────────────────┘
  │
  ├─► 6. Asignar admin
  │   ┌──────────────────────────────────────────┐
  │   │ 📧 Reemplazar email en el script         │
  │   │ ▶️  Ejecutar script de asignación        │
  │   │ ✅ Confirmar admin asignado              │
  │   └──────────────────────────────────────────┘
  │
  ├─► 7. Verificar instalación
  │   ┌──────────────────────────────────────────┐
  │   │ ▶️  Ejecutar script de verificación      │
  │   │ 👀 Revisar que todo muestre ✅           │
  │   └──────────────────────────────────────────┘
  │
  ├─► 8. Esperar y recargar
  │   ┌──────────────────────────────────────────┐
  │   │ ⏱️  Esperar 10 segundos                  │
  │   │ 🔄 Recargar aplicación (F5)              │
  │   └──────────────────────────────────────────┘
  │
  └─► FIN - ✅ Problema solucionado
```

---

## 📈 Estados del Sistema

```
┌────────────────────────────────────────────────────────────────┐
│                  ANTES DE LA SOLUCIÓN                           │
└────────────────────────────────────────────────────────────────┘

auth.users          user_roles           has_role()
┌─────────┐         ┌─────────┐          ┌─────────┐
│ ✅ Existe│         │ ❌ No    │          │ ❌ No    │
│         │         │   existe │          │   existe │
│ user1   │         │         │          │         │
│ user2   │         └─────────┘          └─────────┘
│ user3   │              ↓                     ↓
└─────────┘         ❌ ERROR           ❌ ERROR
                    Políticas RLS      Función
                    no funcionan       no definida


┌────────────────────────────────────────────────────────────────┐
│                  DESPUÉS DE LA SOLUCIÓN                         │
└────────────────────────────────────────────────────────────────┘

auth.users          user_roles           has_role()
┌─────────┐         ┌─────────┐          ┌─────────┐
│ ✅ Existe│ ─────► │ ✅ Existe│ ◄─────  │ ✅ Existe│
│         │  1:N    │         │   usa   │         │
│ user1   │         │ user1:  │          │ Verifica│
│ user2   │         │  admin  │          │ roles   │
│ user3   │         │ user2:  │          │         │
└─────────┘         │  client │          └─────────┘
                    └─────────┘               ↓
                         ↓                ✅ OK
                    ✅ OK              Políticas RLS
                    Datos de roles     funcionan
                    almacenados
```

---

## 🎓 Ejemplo Práctico

### Caso de Uso: Crear política "Solo admins pueden editar productos"

#### ❌ ANTES (con error):

```sql
-- Intentamos crear la política
CREATE POLICY "Solo admins pueden editar productos"
  ON public.products FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

-- Resultado:
❌ ERROR: function public.has_role(uuid, text) does not exist
```

#### ✅ DESPUÉS (funcionando):

```sql
-- 1. Primero ejecutamos la solución (crear has_role)
-- [Ejecutar script de solución...]

-- 2. Ahora SÍ podemos crear la política
CREATE POLICY "Solo admins pueden editar productos"
  ON public.products FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

-- Resultado:
✅ SUCCESS: Policy created successfully

-- 3. Probamos la política
UPDATE products SET price = 99.99 WHERE id = 'xxx';

-- Si eres admin: ✅ UPDATE exitoso
-- Si NO eres admin: ❌ new row violates row-level security policy
```

---

## 🧪 Pruebas Visuales

### Test 1: Verificar que la función existe

```
┌─────────────────────────────────────────────────────┐
│  TEST: ¿Existe la función has_role?                │
├─────────────────────────────────────────────────────┤
│                                                     │
│  SELECT proname, proowner                           │
│  FROM pg_proc                                       │
│  WHERE proname = 'has_role';                        │
│                                                     │
│  Resultado esperado:                                │
│  ┌──────────┬──────────┐                          │
│  │ proname  │ proowner │                          │
│  ├──────────┼──────────┤                          │
│  │ has_role │ postgres │  ✅ OK                   │
│  └──────────┴──────────┘                          │
│                                                     │
│  Si está vacío: ❌ La función NO existe            │
└─────────────────────────────────────────────────────┘
```

### Test 2: Verificar que la tabla existe

```
┌─────────────────────────────────────────────────────┐
│  TEST: ¿Existe la tabla user_roles?                │
├─────────────────────────────────────────────────────┤
│                                                     │
│  SELECT tablename                                   │
│  FROM pg_tables                                     │
│  WHERE tablename = 'user_roles';                    │
│                                                     │
│  Resultado esperado:                                │
│  ┌────────────┐                                    │
│  │ tablename  │                                    │
│  ├────────────┤                                    │
│  │ user_roles │  ✅ OK                             │
│  └────────────┘                                    │
│                                                     │
│  Si está vacío: ❌ La tabla NO existe              │
└─────────────────────────────────────────────────────┘
```

### Test 3: Verificar admin asignado

```
┌─────────────────────────────────────────────────────┐
│  TEST: ¿Hay al menos un admin?                     │
├─────────────────────────────────────────────────────┤
│                                                     │
│  SELECT COUNT(*) as admins                          │
│  FROM public.user_roles                             │
│  WHERE role = 'admin';                              │
│                                                     │
│  Resultado esperado:                                │
│  ┌────────┐                                        │
│  │ admins │                                        │
│  ├────────┤                                        │
│  │   1    │  ✅ OK (o más de 1)                    │
│  └────────┘                                        │
│                                                     │
│  Si es 0: ⚠️  No hay admins asignados              │
└─────────────────────────────────────────────────────┘
```

---

## 📱 Accesos Rápidos

```
╔══════════════════════════════════════════════════════════════╗
║                    ENLACES RÁPIDOS                            ║
╠══════════════════════════════════════════════════════════════╣
║                                                               ║
║  📚 Documentación Completa                                   ║
║  ➜ GUIA_SOLUCION_ERROR_HAS_ROLE.md                          ║
║                                                               ║
║  🎴 Referencia Rápida                                        ║
║  ➜ TARJETA_REFERENCIA_HAS_ROLE.md                           ║
║                                                               ║
║  💾 Script de Migración                                      ║
║  ➜ supabase/migrations/20251124171853_fix_has_role_...sql   ║
║                                                               ║
║  🔍 Script de Diagnóstico                                    ║
║  ➜ scripts/diagnostico_has_role.sql                          ║
║                                                               ║
║  🌐 Dashboard de Supabase                                    ║
║  ➜ https://supabase.com/dashboard                            ║
║                                                               ║
║  📖 Docs Oficiales de RLS                                    ║
║  ➜ https://supabase.com/docs/guides/auth/row-level-security ║
║                                                               ║
╚══════════════════════════════════════════════════════════════╝
```

---

## ⚡ Atajos de Teclado en SQL Editor

```
┌──────────────────────────────────────────────────┐
│  Acción              │  Windows/Linux  │  Mac    │
├──────────────────────┼─────────────────┼─────────┤
│ Ejecutar query       │ Ctrl + Enter    │ Cmd + ↵ │
│ Nueva query          │ Ctrl + N        │ Cmd + N │
│ Formatear SQL        │ Ctrl + Shift+F  │ Cmd+⇧+F │
│ Comentar línea       │ Ctrl + /        │ Cmd + / │
│ Buscar               │ Ctrl + F        │ Cmd + F │
│ Reemplazar           │ Ctrl + H        │ Cmd + H │
│ Seleccionar todo     │ Ctrl + A        │ Cmd + A │
└──────────────────────────────────────────────────┘
```

---

## 🎯 Resumen Visual Final

```
┌────────────────────────────────────────────────────────────┐
│  CHECKLIST DE VERIFICACIÓN VISUAL                          │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  [ ] Abrí Supabase Dashboard                               │
│  [ ] Navegué a SQL Editor                                  │
│  [ ] Ejecuté script de solución                            │
│  [ ] Vi mensajes ✅ de confirmación                        │
│  [ ] Asigné rol admin a mi usuario                         │
│  [ ] Ejecuté script de verificación                        │
│  [ ] Todos los tests muestran ✅                           │
│  [ ] Esperé 10 segundos                                    │
│  [ ] Recargué la aplicación                                │
│  [ ] Probé crear política RLS                              │
│  [ ] ¡FUNCIONA! 🎉                                         │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

---

**Fecha**: 2024-11-24  
**Versión**: 1.0  
**Autor**: Equipo Thuis3D
